Fourteenpress WordPress Theme, Copyright 2018 Noor Alam
Fourteenpress is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

http://www.gnu.org/licenses/gpl-2.0.html

Fourteenpress WordPress Theme is a child theme of Twenty Fourteen WordPress Theme, Copyright 2014 the WordPress team.
Twenty Fourteen WordPress Theme is distributed under the terms of the GNU GPL

Fourteenpress WordPress Theme bundles the following third-party resources:

Images used in the screenshot are licensed under CC0 (which is compatible with GNU GPL).
Source: https://hd.unsplash.com/photo-1470897655254-05feb2d2ab97
Source: https://hd.unsplash.com/photo-1459445364195-16475050193c



